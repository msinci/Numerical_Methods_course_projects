function [ out ] = fpgx( x )
% gx function used for fixed point method
    out = cos(x^2);
end

