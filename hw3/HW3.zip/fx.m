function [ out ] = fx( x )
% fx function given in the problem
    out = x^3 - x -3;
end

